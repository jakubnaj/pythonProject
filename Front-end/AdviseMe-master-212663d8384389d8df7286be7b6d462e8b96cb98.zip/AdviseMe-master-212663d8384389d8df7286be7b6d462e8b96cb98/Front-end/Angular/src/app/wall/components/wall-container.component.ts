import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-wall-container',
  templateUrl: './wall-container.component.html',
  styleUrls: ['./wall-container.component.scss']
})
export class WallContainerComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
